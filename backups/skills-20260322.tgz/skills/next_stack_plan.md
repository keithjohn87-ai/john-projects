# Next Stack Map (8-hour block)

## Hour 1: Research Core
- Install & configure `search-research`
- Install `airadar`
- Install `amazon-product-api`
- Verify Tavily skill (API key + env vars)

## Hour 2: Dev & System
- Install `debug-pro`
- Install `code-review`
- Install `architecture-blueprint-generator`
- Prep docker/microservices skill list

## Hour 3: Data & Docs
- Install `pdf-documents`
- Install `data-analytics`
- Pull `science` toolkit

## Hour 4: Communication & Social
- Install `communication-advisor`
- Install `meeting-intelligence`
- Install `negotiation-strategist`

## Hour 5: Creative & Generative
- Install `content-engine`
- Install `creative-director`
- Install `simulation-runner`

## Hour 6: Business & Strategy
- Install `financial-modeler`
- Install `competitive-intelligence`
- Install `strategic-planner`

## Hour 7: Personal/Operational Layers
- Install `knowledge-curator`
- Install `habit-architect`
- Install `learning-accelerator`

## Hour 8: Advanced/Monitoring
- Install `proactive-monitor`
- Install `goal-planner`
- Install `self-correction`
- Tie into `learning-engine` scaffolding
