// TradeElegance - Construction Template Scripts
